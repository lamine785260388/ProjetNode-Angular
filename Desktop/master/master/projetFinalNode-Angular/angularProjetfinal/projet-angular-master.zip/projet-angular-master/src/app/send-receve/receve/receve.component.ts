import { Component } from '@angular/core';

@Component({
  selector: 'app-receve',
  templateUrl: './receve.component.html',
  styleUrls: ['./receve.component.css']
})
export class ReceveComponent {

}
